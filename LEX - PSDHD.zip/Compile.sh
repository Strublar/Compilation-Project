flex psdhd.l
gcc lex.yy.c -o psdhd.exe
